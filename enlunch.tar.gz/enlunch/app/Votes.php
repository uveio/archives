<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use DB;

class Votes extends Model
{
    protected $table = 'votes';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = array('ticket', 'restaurant_id', 'user_id');

    public function vote($ticket, $userId, $restaurantId) {
        $data = array(
            'ticket'        =>  $ticket,
            'restaurant_id' =>  $restaurantId,
            'user_id'       =>  $userId,
        );
        try {
            $this->create($data);
        } catch(QueryException $err) {
            return false;
        }
        return true;
    }

    public function countVotes($restaurantId, $date = NULl) {

        $date = $date === NULL ? date('Y-m-d') : $date;
        $startTime =  date('Y-m-d H:i:s', strtotime($date));
        $endTime = date('Y-m-d H:i:s', strtotime($date) + 60*60*24);

        $count = DB::select('select count(*) as total from votes where restaurant_id = ? and create_time >= ? and create_time < ?', [(int)$restaurantId, $startTime, $endTime]);
        return $count[0]->total;

    }
}
