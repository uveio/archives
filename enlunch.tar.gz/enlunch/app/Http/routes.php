<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    echo "Index page comming soon.";
});

Route::get('/restaurant', function () {
    return view('restaurantManager');
});
Route::post('/restaurant', 'RestaurantController@insertDB'); 

Route::get('/user', function () {
    return view('userManager');
});
Route::post('/user', 'UserController@insertDB'); 
//send daily_options emails
Route::get('/send/daily', 'RecommendController@sendDailyOptions');

Route::get('/send/today', 'RecommendController@sendTodayResult');

Route::get('/vote', 'RecommendController@collectVotes');

Route::get('/config/{opt}', function($opt) {
    $DailyController = new \App\Http\Controllers\DailyController();
    return $DailyController->index($opt);
});

Route::get('/test', 'TestController@index');

