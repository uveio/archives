<?php

namespace App\Http\Controllers;

use Mail;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class MailController extends Controller
{
    const daily_options_email_title = '午餐推荐方案征集';
    const daily_result_email_title = '最终午餐方案';

    public function test($receiver) {
        Mail::send('emails.test', ['key' => 'value'], function($message) use ($receiver)
        {
            $message->from('test@enlunch.com', '测试账户')->to("$receiver", '用户')->subject('来自enlunch的测试邮件!');
        });
    }

    public static function todayOptions($options, $users) {
        foreach($users as $user) {
            Mail::send('emails.options', ['options' => $options, 'user' => $user], function($message) use ($user)
            {
                $message->from('lunch@enlunch.com', '午餐去哪吃')->to($user->email, 'UVE-RD')->subject(self::daily_options_email_title . ' - ' . date('Y-m-d', time()));
            });
        }
        echo "Success: Daily options sent." . PHP_EOL;
    }

    public static function finalResult($restaurant, $list) {
        foreach($list as $user) {
            Mail::send('emails.today', ['restaurant' => $restaurant], function($message) use ($user)
            {
                $message->from('lunch@enlunch.com', '午餐去哪吃')->to($user->email, 'UVE-RD')->subject(self::daily_result_email_title . ' - ' . date('Y-m-d', time()));
            });
        }
        echo "Success: Today result sent." . PHP_EOL;
    }
}
