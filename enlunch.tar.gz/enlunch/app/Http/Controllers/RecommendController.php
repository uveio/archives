<?php

namespace App\Http\Controllers;

use App\DailyConfig;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Restaurant;
use App\User;
use App\Votes;
use App\Http\Controllers\Controller;
use Storage;
use Input;


class RecommendController extends Controller
{

    const ticket_folder = '/daily_tickets';

    public function sendDailyOptions() {
        $Restaurant = new Restaurant();
        $User = new User();
        $DailyConfig = new DailyConfig();
        $today = date('Y-m-d');

        $mode = $DailyConfig->mode($today);
        if ($mode != NULL ) {
            if ($mode != "routine")
                die('Exit: Not routine day' . PHP_EOL);
        } else {
            die('Error: No config record for today' . PHP_EOL);
        }

        $list = $Restaurant->getDailyOptions();
        $users = $User::where('is_active', 1)->get(['id', 'name', 'email']);
        foreach ($users as &$user) {
            $ticket = $today . '#' . $user['id'] . '$' . rand(100000, 999999) . '~……*###';
            $ticket = md5($ticket);
            $user->ticket = $ticket;
        }

        //Store daily tickets in files
        if (!is_dir(storage_path('app') . self::ticket_folder)) {
            Storage::makeDirectory(self::ticket_folder);
        }
        //files are named like 1970-01-01_tickets under /daily_tickets
        $ticketFile = self::ticket_folder . '/' . $today . '_tickets';
        if (Storage::exists($ticketFile)) {
            die('Error: Today\'s ticket already exists' . PHP_EOL);
        }
        foreach ($users as $user) {
            Storage::append($ticketFile, $user->id . ' ' . $user->ticket);
        }
        return MailController::todayOptions($list, $users);
    }

    public function sendTodayResult() {
        $Restaurant = new Restaurant();
        $Votes = new Votes();
        $User = new User();
        $DailyConfig = new DailyConfig();
        $today = date('Y-m-d');

        $mode = $DailyConfig->mode($today);
        if ($mode != NULL ) {
            if ($mode != "routine")
                die('Exit: Not routine day' . PHP_EOL);
        } else {
            die('Error: No config record for today' . PHP_EOL);
        }

        $options = $Restaurant->getDailyOptions();
        $maxCounter = 0;
        foreach ($options as $option) {
            $mostVoted = isset($mostVoted) ? $mostVoted : $option;
            $votes = $Votes->countVotes($option['id']);
            if ($votes > $maxCounter) {
                $maxCounter = $votes;
                $mostVoted = $option;
            }
        }
        Storage::put('/daily_results/' . date('Y-m-d') . '_result', $mostVoted['id']);
        $users = $User::where('is_active', 1)->get(['email']);
        return MailController::finalResult($mostVoted['name'], $users);
    }

    public function collectVotes() {
        $userTicket = Input::get('ticket');
        $vote = Input::get('votefor');
        $ticketFile = self::ticket_folder . '/' . date('Y-m-d') . '_tickets';
        $ticketInfo = Storage::get($ticketFile);
        $ticketInfo = explode(PHP_EOL, $ticketInfo);
        //$ticketList stores [userid => ticket]
        $ticketList = array();
        foreach ($ticketInfo as $ticket) {
            $tmp = explode(' ', $ticket);
            $ticketList[$tmp[0]] = $tmp[1];
        }
        foreach ($ticketList as $id => $ticket) {
            if ($ticket === $userTicket) {
                $Vote = new Votes();
                $userId = $id;
                $result = $Vote->vote($userTicket, $userId, $vote);
                if ($result) {
                    return "投票成功";
                } else {
                    die('Already voted or invalid argument');
                }
            }
        }
        die('Invalid ticket');
    }
}
