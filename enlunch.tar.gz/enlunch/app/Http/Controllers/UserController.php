<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;

class UserController extends Controller
{
    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function insertDB()
    {
	$username = $_POST['username'];
	$email= $_POST['email'];
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$passwd = $_POST['passwd'];
	$gender= $_POST['gender'];

	$model = new \App\User();
	$model::create(['username' => $username, 'email' => $email, 'name' => $name, 'phone' => $phone, 'passwd' => $passwd, 'gender' => $gender]); 
    }
}
