<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;

class RestaurantController extends Controller
{
    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function insertDB()
    {
	$name = $_POST['name'];
	isset($_POSET['location']) ? $location = $_POST['location'] : $location = '北京';
	isset($_POST['phone']) ? $phone = $_POST['phone'] : '';
	isset($_POST['daily']) ? $daily = 1 : $daily = 0; 
	isset($_POST['take_out']) ? $take_out = 1 : $take_out = 0;

	$model = new \App\Restaurant();
	$model::create(['name' => $name, 'location' => $location, 'phone' => $phone, 'daily' => $daily, 'take_out' => $take_out]);
 	//header("location: ../../../resources/views/restaurantManager.blade.php");
 	 }
}
