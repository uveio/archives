<?php

namespace App\Http\Controllers;

use App\DailyConfig;
use App\Restaurant;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Storage;

class DailyController extends Controller
{
    public function index($opt) {
        switch ($opt) {
            case "auto":
                return $this->autoCreate();
                break;
            case "off":
                return $this->off();
            case "apply_result":
                return $this->applyResult();
            default:
                die('Config option not found');
        }
    }

    private function autoCreate() {
        $DailyConfig = new DailyConfig();
        $today = date('Y-m-d');
        $exist = $DailyConfig->checkDate($today);
        if (!$exist) {
            $mode = date('N') > 5 ? 'off' : 'routine';
            $DailyConfig->writeConfig($today, $mode);
            echo('Success: Today auto configured to ' . $mode . PHP_EOL);
        } else {
            die('Failure: Config already exists '. PHP_EOL);
        }
    }

    // This is a temporary function and will be removed when more modes added.
    private function off() {
        $today = date('Y-m-d');
        $DailyConfig = new DailyConfig();
        $DailyConfig->updateMode($today, 'off');
        echo "set to off";
    }

    private function applyResult() {
        $today = date('Y-m-d');
        $DailyConfig = new DailyConfig();
        $mode = $DailyConfig->mode($today);
        if ($mode == "routine") {
            $file = '/daily_results/' . date('Y-m-d') . '_result';
            if (Storage::exists($file)) {
                $restaurantId = intval(Storage::get($file));
                if ($restaurantId < 1) {
                    die('Error: Empty daily result data');
                }
                $Restaurant = new Restaurant();
                $r = $Restaurant->updateLastVisit($restaurantId, $today);
                if ($r) {
                    echo 'Updated today\'s routine restaurant, id :' . $restaurantId . PHP_EOL;
                }
            } else {
                die('Error: Result file does not exist');
            }
        }
    }
}
