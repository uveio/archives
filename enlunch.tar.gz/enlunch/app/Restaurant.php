<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Storage;
use DB;

class Restaurant extends Model
{
    protected $table = 'restaurant';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = array('name', 'location', 'phone', 'daily', 'take_out');

    const num_daily_options = 2;
    const options_folder = '/daily_options';

    public function getDailyOptions() {
        $Restaurant = new Restaurant();
        $columns = array('id', 'name');
        //拉取过去4天内没有去过的餐厅,保证同一周内不会提过已经去过餐厅作为选项
        $cond = array(
            'daily'         =>  1,
            'last_visit'    =>  null,
        );
        $list = $Restaurant::where($cond)
            ->orWhere(function ($query) {
                $query->where('last_visit', '<', date('Y-m-d', strtotime('-4 days')))
                      ->where('daily', 1);
            })
            ->get($columns)->toArray();

        $data = array();
        //Store daily options in files
        if (!is_dir(storage_path('app') . self::options_folder)) {
            Storage::makeDirectory(self::options_folder);
        }
        //files are named like 1970-01-01_options under /daily_options
        $optionsFile = self::options_folder . '/' . date('Y-m-d') . '_options';
        if (Storage::exists($optionsFile)) {
            $existedData = Storage::get($optionsFile);
            $existedData = explode(PHP_EOL, $existedData);
            foreach ($existedData as $record) {
                $tmp = explode(' ', $record, 2);
                array_push($data, ['id' => (int)$tmp[0], 'name' => $tmp[1]]);
            }
        } else {
            //The following three lines added newly added restaurants into daily option list
            $optionalList = $Restaurant->getNewlyAdded();
            if ($optionalList != null)
                array_push($data, head($optionalList));
            for ($i = 0; $i < self::num_daily_options; $i++) {
                $rand = rand(1, count($list));
                array_push($data, $list[$rand -1]);
                unset($list[$rand -1]);
                $list = array_values($list);
            }
            foreach ($data as $option) {
                Storage::append($optionsFile, $option['id'] . ' ' . $option['name']);
            }
        }
        return $data;
    }

    public function getNewlyAdded() {
        $Restaurant = new Restaurant();
        $columns = array('id', 'name');
        $cond = array(
            'daily'         =>  1,
            'last_visit'    =>  null,
        );
        $list = $Restaurant::where($cond)->where('create_time', '>', date('Y-m-d', strtotime('-10 days')))->get($columns)->toArray();
        $count = count($list);
        if ($count >= 1) {
            $list = array($list[rand(0, $count - 1)]);
            $list[0]['name'] .= '(新添加)';
        }
        return count($list) == 1 ? $list : null;
    }

    public function updateLastVisit($restaurantId, $date) {
        $r = $this::where('id', $restaurantId)->update(['last_visit' => $date]);
        if ($r) {
            DB::table($this->table)->where('id', $restaurantId)->increment('go_counts');
            return true;
        }
        return false;
    }
}
