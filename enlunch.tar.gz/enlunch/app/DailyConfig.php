<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DailyConfig extends Model
{
    protected $table = 'daily_config';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = array('date', 'mode');


    /**
     * 检查某一特定日期在数据库中是否已存在配置记录
     *
     * @param $date date 格式使用如'2015-01-01'
     * @return bool true if record exists, false when record not found
     */
    public function checkDate($date = NULL) {
        $date = ($date === NUll) || strlen($date) != 10? date('Y-m-d') : $date;
        $exist = $this::where('date', $date)->first();
        return $exist === NULL ? false : true;
    }

    public function writeConfig($date, $mode) {
        $data = array(
            'date'  =>  $date,
            'mode'  =>  $mode,
        );
        return $this->create($data);
    }

    public function updateMode($date, $mode) {
        return $this::where('date', $date)->update(['mode' => $mode]);
    }

    public function mode($date) {
        $cond = array(
            'date'  =>  $date,
        );
        $r = $this::where($cond)->first(['mode']);
        return $r === NULL ? NULL : $r->mode;
    }
}
