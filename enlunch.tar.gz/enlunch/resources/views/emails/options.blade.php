 <p>今天系统随机推荐的午餐方案为:</p>
    <table border="0">
        <tr>
            @foreach ($options as $restaurant)
            <td style="text-align: center">{{ $restaurant['name'] }}</td>
            @endforeach
        </tr>
        <tr>
            @foreach ($options as $restaurant)
            <td style="border-radius: 2em;color: #606060;border: solid 1px #b7b7b7;background:
            -webkit-gradient(linear, left top, left bottom, from(#fff), to(#ededed));display: inline-block;
                outline: none;cursor: pointer;text-align: center;
                padding: .5em 2em .55em;text-shadow: 0 1px 1px rgba(0,0,0,.3);box-shadow: 0 1px 2px rgba(0,0,0,.2);"><a style="text-decoration: none;" href="http://enlunch.com/vote?ticket={{ $user->ticket }}&votefor={{ $restaurant['id'] }}">投票</a>
            </td>
            @endforeach
        </tr>
    </table>
 <p style="font-style: italic; font-size: smaller">请各位在11:00前完成投票,点击餐厅下方对应投票按钮即可!</p>
