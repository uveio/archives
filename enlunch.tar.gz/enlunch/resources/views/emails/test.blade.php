
<h4>这是一封来自enlunch的测试邮件</h4>

<p>系统使用{{ env('MAIL_DRIVER', '未知') }}方式发送的此邮件.</p>

