<div>今天我们的午餐推荐方案已确定。<br />
根据投票结果，我们去吃<b>{{ $restaurant }}</b>!
</div>