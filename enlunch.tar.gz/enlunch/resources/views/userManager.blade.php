<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>


        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                display: table;
                font-weight: 100;
            }

            .container {
                text-align: center;
                display: table-cell;
                vertical-align: middle;
            }

            .content {
                text-align: center;
                display: inline-block;
            }

            .title {
                font-size: 96px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="content">
                <div class="title">用户管理</div>
		     <form action="/user" method="post">
			别名:
			<input type="text" name="username"></p>
			邮件:
			<input type="text" name="email"></p>
			姓名:
			<input type="text" name="name"></p>
			手机:
			<input type="text" name="phone"></p>
			密码:
			<input type="passwd" name="passwd"></p>
			性别:
		 	&nbsp;&nbsp;
			<input type="radio" name="gender" value="male">男
		 	&nbsp;&nbsp;
			<input type="radio" name="gender" value="female">女</p>

			<input type="hidden" name="_token" value="{{ csrf_token() }}">
			<input type="submit" value="提交">
			&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
			<input type="reset" value="重置">
		    </form>
            </div>
        </div>
    </body>
</html>
