<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>


        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                display: table;
                font-weight: 100;
            }

            .container {
                text-align: center;
                display: table-cell;
                vertical-align: middle;
            }

            .content {
                text-align: center;
                display: inline-block;
            }

            .title {
                font-size: 96px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="content">
                <div class="title">餐厅管理</div>
		     <form action="/restaurant" method="post">
			名字:
			<input type="text" name="name"></p>
			位置:
			<input type="text" name="location"></p>
			电话:
			<input type="text" name="phone"></p>
			日常:
			<input type="checkbox" name="daily" value="1">
			外卖:
			<input type="checkbox" name="take_out" value="1"></p>
			<input type="hidden" name="_token" value="{{ csrf_token() }}">
			<input type="submit" value="提交">
			&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
			<input type="reset" value="重置">
		    </form>
            </div>
        </div>
    </body>
</html>
