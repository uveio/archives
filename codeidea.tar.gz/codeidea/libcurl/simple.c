#include <stdio.h>
#include <curl/curl.h>
#include <unistd.h>

size_t write_callback(char *ptr, size_t size, size_t nmemb, void *userdata);

int main(void)
{
  CURL *curl;
  CURLcode res;

  curl = curl_easy_init();
  if(curl) {
    curl_easy_setopt(curl, CURLOPT_URL, "http://lib.fwso.cn/302.php");
    /* example.com is redirected, so we tell libcurl to follow redirection */
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    
    //curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);

    //curl_easy_setopt(curl, CURLOPT_TIMEOUT, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, 1000L);

    curl_easy_setopt(curl, CURLOPT_HEADER, 1L);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);

    /* Perform the request, res will get the return code */
    res = curl_easy_perform(curl);
    /* Check for errors */
    if(res != CURLE_OK)
      fprintf(stderr, "curl_easy_perform() failed: %s\n",
              curl_easy_strerror(res));

    /* always cleanup */
    curl_easy_cleanup(curl);
  }
  return 0;
}

size_t write_callback(char *ptr, size_t size, size_t nmemb, void *userdata)
{
    //printf("%ld, %ld\n", size, nmemb);
    if (size > 0) {
        write(1, ptr, size*nmemb);
    }
    return size * nmemb;
}

