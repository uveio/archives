package main

import (
    "fmt"
    "net"
    "io"
)

func main() {
    listener, err := net.Listen("tcp", "0.0.0.0:1234")
    if err != nil {
        panic("listen error: " + err.Error())
    }
    fmt.Println("server start ...")

    for {
        conn, err := listener.Accept()
        if err != nil {
            panic("accept error: " + err.Error())
        }
        fmt.Println("accept a new connection: ", conn.RemoteAddr())
        go echo_server(conn)
    }
}

func echo_server(conn net.Conn) {
    buf := make([]byte, 2048)
    defer conn.Close()

    for {
        n, err := conn.Read(buf)
        switch err {
        case nil:
            conn.Write(buf[0:n])
        case io.EOF:
            fmt.Println("Warnning: End of data: %s\n", err.Error())
            return
        default:
            fmt.Println("Error: Reading data: %s\n", err.Error())
            return
        }
    }
}
