package main

import (
	"fmt"
	"math/rand"
	"time"
)

func SubReq(i int) {
	time.Sleep(time.Duration(rand.Intn(1000)) * time.Millisecond)
	fmt.Printf("Hello from %d\n", i)
}

func main() {
	fmt.Println("Start...")

	defer fmt.Println("Done")

	for i := 0; i < 10; i++ {
		go SubReq(i)
	}
}
