package main

import (
	"fmt"
	"io"
	"log"
	"net"
	"time"
)

func main() {

	// Listen on TCP port 2000 on all interfaces.
	l, err := net.Listen("tcp", ":2000")

	if err != nil {
		log.Fatal(err)
	}

	connCount := 0

	defer l.Close()

	for {
		// Wait for a connection.
		conn, err := l.Accept()
		if err != nil {
			log.Fatal(err)
		}
		// Handle the connection in a new goroutine.
		// The loop then returns to accepting, so that
		// multiple connections may be served concurrently.
		go func(c net.Conn) {
			connCount++
			// Echo all incoming data.
			var buf = make([]byte, 1024)

			for {
				n, err := c.Read(buf)
				t := time.Now()
				//fmt.Println(n, err)
				if err == io.EOF {
					break
				}
				//time.Sleep(time.Duration(rand.Intn(100)) * time.Millisecond)
				fmt.Println("#", connCount, t, string(buf[:n-2]))
				fmt.Fprintln(c, "#", connCount, t, string(buf[:n-2]))
				//c.Write(buf)
				//io.Copy(c, c)
				// Shut down the connection.
			}
			c.Close()
		}(conn)
	}
}
