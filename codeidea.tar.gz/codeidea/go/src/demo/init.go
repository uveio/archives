package main

import "fmt"

type Node struct {
	name string
	age  int
}

func main() {
	var n Node
	p := new(Node)
	n.name = "James Tang"
	p.name = "Peter"
	fmt.Printf("%T: %s, %d\n", n, n.name, n.age)
	fmt.Printf("%T: %s, %d\n", p, p.name, p.age)
	fmt.Printf("%T: %s, %d\n", p, (*p).name, (*p).age)
}
