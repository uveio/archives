package main

import (
    "fmt"
    "net"
    "time"
)

func main() {
    buf := make([]byte, 2048)

    for i := 0; i < 5; i++ {
        conn, err := net.Dial("tcp", "127.0.0.1:6666")
        if err != nil {
            panic("dial error: " + err.Error())
        }

        msg := fmt.Sprintf("Hello, 你好, This is %d", i)
        n, err := conn.Write([]byte(msg))
        if err != nil {
            println("write buffer error: ", err.Error())
            break
        }
        fmt.Println(msg)

        n, err = conn.Read(buf)
        if err != nil {
            println("read buffer error: ", err.Error())
            break
        }
        fmt.Println("echo: ", string(buf[0:n]))

        time.Sleep(time.Second)
        conn.Close()
    }
}
