package main

import (
	"fmt"
	"math/rand"
	"time"
)

var sem = make(chan int, 10)

func SubReq(i int) {
	time.Sleep(time.Duration(rand.Intn(1000)) * time.Millisecond)
	fmt.Printf("Hello from %d\n", i)
	sem <- i
}

func main() {
	defer fmt.Println("Done")

	for i := 0; i < 100000; i++ {
		go SubReq(i)
	}

join_loop:
	for {
		select {
		case i := <-sem:
			fmt.Println(i, "finished")
		case <-time.After(time.Second * 10):
			break join_loop
		}
	}
	fmt.Println("Done")
}
