package main

import (
	"fmt"
	"io"
	"math/rand"
	"net"
	"time"
)

func echo_msg(conn net.Conn) {
	buf := make([]byte, 1024)

	n, err := conn.Read(buf)
	switch err {
	case nil:
		conn.Write(buf[0:n])
	case io.EOF:
		fmt.Println("Warnning: end of data: ", err.Error())
	default:
		fmt.Println("Error: reading data: ", err.Error())
	}
	conn.Close()
}

func work_routine(name string, channel chan net.Conn) {
	fmt.Println(">>>>", name)
	for {
		select {
		case conn := <-channel:
			echo_msg(conn)
		case <-time.After(time.Second * 120):
			fmt.Println("Time out (120s)")
		}
	}
}

func main() {
	var channel [8]chan net.Conn
	for i := 0; i < 8; i++ {
		channel[i] = make(chan net.Conn)
		name := fmt.Sprintf("goroutine_", i)
		go work_routine(name, channel[i])
	}

	listener, err := net.Listen("tcp", "0.0.0.0:6666")
	if err != nil {
		panic("listen error:" + err.Error())
	}
	fmt.Println("start ...")

	var rand_num int
	rand.Seed(time.Now().Unix())

	for {
		conn, err := listener.Accept()
		if err != nil {
			panic("accept error: " + err.Error())
		}
		fmt.Println("accept new connection: ", conn.RemoteAddr())

		rand_num = rand.Intn(8)
		channel[rand_num] <- conn
		println("send connection to routine: ", rand_num)
	}
}
