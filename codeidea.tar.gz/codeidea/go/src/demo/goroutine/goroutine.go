package main

import (
	"fmt"
	"math/rand"
	"time"
)

var chn = make(chan int)

func SubReq(i int) {
	time.Sleep(time.Duration(rand.Intn(1000)) * time.Millisecond)
	fmt.Printf("Hello from %d\n", i)
	chn <- 1
}

func main() {
	defer fmt.Println("Done")

	for i := 0; i < 10; i++ {
		go SubReq(i)
	}

	for i := 0; i < 10; i++ {
		select {
		case <-chn:
		}
	}
}
