package main

import "fmt"

func main() {
    var dict map[string]int = make(map[string]int, 1)
    dict["name"] = 1
    dict["cat"] = 100
    fmt.Println(len(dict))
    for k, v := range dict {
        fmt.Println(k, v)
    }
}
