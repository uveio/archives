package main

import (
	"fmt"
	"math/rand"
	"time"
)

func SubReq(i int, c chan string) {
	time.Sleep(time.Duration(rand.Intn(1000)) * time.Millisecond)
	c <- fmt.Sprintf("[1]Hello from %d", i)
}

func main() {
	defer fmt.Println("Done")
	c := make(chan string)

	for i := 0; i < 10; i++ {
		go SubReq(i, c)
	}

	for i := 0; i < 10; i++ {
		select {
		case s := <-c:
			fmt.Println(s)
		case <-time.After(time.Millisecond * 100):
			fmt.Printf("%d timeout\n", i)
		}
	}
}
