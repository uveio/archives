package main

import "fmt"

func bubble_sort(n []int) {
    for i := 0; i < len(n) - 1; i++ {
        for j := 0; j < len(n) - i - 1; j++ {
            if n[j] > n[j+1] {
                n[j], n[j+1] = n[j+1], n[j]
            }
        }
    }
}

func bubble_sort2(n []int) {
    for i := 0; i < len(n) - 1; i++  {
        for j := i + 1; j < len(n); j++ {
            if n[j] < n[i] {
                n[i], n[j] = n[j], n[i]
            }
        }
    }
}

func main() {
    n := []int {5, -1, 0, 12, 3, 5}
    fmt.Printf("unsorted %v\n", n)
    bubble_sort(n)
    fmt.Printf("sorted %v\n", n)
    bubble_sort2(n)
    fmt.Printf("sorted %v\n", n)
}
