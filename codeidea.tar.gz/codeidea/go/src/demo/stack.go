package main

import "fmt"

type stack struct {
    index int
    data  [10]int
}

func (s *stack)push(k int) {
    if s.index >= 9 {
        return
    }
    s.data[s.index] = k
    s.index++
}

func (s *stack)pop() int {
    s.index--
    return s.data[s.index]
}

func main() {
    var s stack

    s.push(28)
    s.push(39)
    s.push(40)
    fmt.Printf("stack %v\n", s)

    a := s.pop()
    fmt.Printf("stack pop: %d\n", a)

    fmt.Printf("stack %v\n", s)
}
