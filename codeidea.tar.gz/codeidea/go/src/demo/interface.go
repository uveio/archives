package main

import "fmt"

type Demo interface {
    Hello()
    World()
}

type HelloDemo struct {
}

func (p HelloDemo) Hello() {
    fmt.Println("Hello()")
}

func (p HelloDemo) World() {}

type WorldDemo struct {
}

func (p WorldDemo) Hello() {}

func (p WorldDemo) World() {
    fmt.Println("World()")
}

func HelloMain(i Demo) {
    i.Hello()
}

func WorldMain(i Demo) {
    i.World()
}

func main() {
    var d HelloDemo
    var p WorldDemo
    HelloMain(d)
    WorldMain(p)
}
