/*
Demo package
*/
package main

import (
	"demo/string"
	"fmt"
)

func main() {
	fmt.Println(string.Reverse("Hello, world!"))
}
