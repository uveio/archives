
function test()
    print('Hello, world from lua script')
end

function sayhello(name)
    --print('Hello, ' .. tostring(name))
    return 'Hello, ' .. tostring(name), 'second'
end

test()

