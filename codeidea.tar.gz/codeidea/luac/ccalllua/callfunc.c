/**
 * Usage: 
 * ./callfunc hello.lua  test
 *
 */
#include <stdio.h>
#include <stdlib.h>

#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

int main(int argc, char **argv)
{
    lua_State *L;

    if (argc < 3) {
        fprintf(stderr, "Usage: %s LUA_SCRIPT_FILE FUNCTION_NAME\n", argv[0]);
        exit(1);
    }

    L = luaL_newstate();
    luaL_openlibs(L);

    if (luaL_loadfile(L, argv[1])) {
        fprintf(stderr, "\nFatal Error: \n luaL_loadfile() failed: %s\n\n", lua_tostring(L, -1));
        exit(1);
    }

    if (lua_pcall(L, 0, 0, 0) != LUA_OK) {
        fprintf(stderr, "\nFatal Error: \n lua_pcall() failed: %s\n\n", lua_tostring(L, -1));
        exit(1);
    }

    lua_getglobal(L, argv[2]);

    if (lua_pcall(L, 0, 0, 0) != LUA_OK) {
        fprintf(stderr, "\nFatal Error: \n lua_pcall() failed: %s\n\n", lua_tostring(L, -1));
        exit(1);
    }

    lua_close(L);
    return 0;
}

