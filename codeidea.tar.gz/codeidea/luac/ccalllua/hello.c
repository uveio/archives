#include <stdio.h>
#include <stdlib.h>

#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

int main(int argc, char **argv)
{
    lua_State *L;
    L = luaL_newstate();
    luaL_openlibs(L);

    if (luaL_loadfile(L, "hello.lua")) {
        fprintf(stderr, "\nFatal Error: \n luaL_loadfile() failed: %s\n\n", lua_tostring(L, -1));
        exit(1);
    }

    if (lua_pcall(L, 0, 0, 0) != LUA_OK) {
        fprintf(stderr, "\nFatal Error: \n lua_pcall() failed: %s\n\n", lua_tostring(L, -1));
        exit(1);
    }

    lua_close(L);
    return 0;
}

