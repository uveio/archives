/**
 * Usage: 
 * ./callfunc2 hello.lua  sayhello james
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

int main(int argc, char **argv)
{
    int EXIT_CODE = 0;
    lua_State *L;

    if (argc < 4) {
        fprintf(stderr, "Usage: %s LUA_SCRIPT_FILE FUNCTION_NAME ARG\n", argv[0]);
        exit(1);
    }

    L = luaL_newstate();
    luaL_openlibs(L);

    if (luaL_loadfile(L, argv[1])) {
        fprintf(stderr, "\nFatal Error: \n luaL_loadfile() failed: %s\n\n", lua_tostring(L, -1));
        EXIT_CODE = 0;
        goto _exit;
    }

    if (lua_pcall(L, 0, 0, 0) != LUA_OK) {
        fprintf(stderr, "\nFatal Error: \n lua_pcall() failed: %s\n\n", lua_tostring(L, -1));
        goto _exit;
    }

    lua_getglobal(L, argv[2]);
    if (lua_checkstack(L, 1)) {
        //lua_pushnumber(L, atoi(argv[3]));
        //lua_pushstring(L, argv[3]);
        lua_pushlstring(L, argv[3], 3);
        int fd = open("/proc/self/status", O_RDONLY);
        int len = 0;
        char buf[1024];
        while ((len = read(fd, buf, 1024))) {
            write(1, buf, len);
        }
        close(fd);
    } else {
        fprintf(stderr, "NO enough space for stack in Lua");
        goto _exit;
    }

    if (lua_pcall(L, 1, 2, 0) != LUA_OK) {
        fprintf(stderr, "\nFatal Error: \n lua_pcall() failed: %s\n\n", lua_tostring(L, -1));
        goto _exit;
    }

    printf("Returned: %s\n", lua_tostring(L, -1));
    printf("Returned: %s\n", lua_tostring(L, -2));

    lua_getglobal(L, "sayhello");
    lua_pushstring(L, "Peter");
    lua_pcall(L, 1, 2, 0);
    printf("Returned: %s\n", lua_tostring(L, -1));
    printf("Returned: %s\n", lua_tostring(L, -2));
    printf("Returned: %s\n", lua_tostring(L, -3));
    printf("Returned: %s\n", lua_tostring(L, -4));

_exit:
    lua_close(L);
    printf("Done\n");
    return 0;
}

