/**
 * > hello = require("hello")
 * > print(hello.hello("James Tang"))
 */
#include "hello.h"
#include <string.h>
#include <stdlib.h>

static int c_hello(lua_State *L) {
    if (!lua_isstring(L, -1)) {
        luaL_error(L, "bad argument #1 to hello: string expected, got %s", luaL_typename(L, -1));
    }
    size_t len;
    const char *name = lua_tolstring(L, -1, &len);

    //char *str;
    //str = (char *) malloc(strlen("Hello, ") + len);
    //sprintf(str, "Hello, %s", name);
    //lua_pushstring(L, str);

    printf("From C: %s\n", lua_pushfstring(L, "Hello, %s", name));

    return 1;
}


int luaopen_hello(lua_State *L) {
    luaL_newlib(L, hello);
    return 1;
}
