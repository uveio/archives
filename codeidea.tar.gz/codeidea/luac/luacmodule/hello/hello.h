#ifndef __HELLO_H__
#define __HELLO_H__

#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

static int c_hello(lua_State *L);
static const struct luaL_Reg hello[] = {
    {"hello", c_hello},
    {NULL, NULL}
};

int luaopen_hello(lua_State *L);

#endif
