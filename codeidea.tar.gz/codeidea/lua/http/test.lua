
--ngx.sleep(1)
ngx.say('Hello, world')

