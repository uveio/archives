
ngx.say('Lua works,正常工作!\n')


