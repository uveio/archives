module(..., package.seeall)

function multi(reqs)
    ngx.say('Request count: ' .. #reqs)
    local threads = {}
    for i, req in ipairs(reqs) do
        local t, err = ngx.thread.spawn(request, req)
        if not t then
            ngx.say('error: failed to spawn thread #' .. i)
        else
            table.insert(threads, t)
        end
    end

    for i = 1, #threads do
        local ok, res, err = ngx.thread.wait(threads[i])
        if not ok then
            ngx.say(i, ' error: failed to run: ', err)
        else
            if not res then
                ngx.say(i, ' requset error: ', err)
            else
                ngx.say(i, ' wait ok: ', res.body)
            end
        end
    end
end

function request(req)
    local rhttp = require('resty.http')
    local httpc = rhttp.new()
    local uri = httpc:parse_uri(req.uri)

    httpc:connect(uri[2], uri[3])
    httpc:set_timeout(req.timeout or 100)
    req.path = uri[4]
    
    if not req.headers then
        req.headers = {}
    end

    if not req.method then
        req.method = 'GET'
    end

    if not req.headers['Host'] then
        req.headers['Host'] = uri['2']
    end

    req.headers['Connection'] = 'keep-alive'

    local resp, err = httpc:request(req)

    if not resp then
        resp = {}
        resp.errno = 504
        resp.error = err
    else
        resp.errno = 200
        resp.error = ''
        local reader = resp.body_reader
        local data = {}

        repeat
            local chunk, err = reader(8192)
            if err then
                resp.errno = 500
                resp.error = err
                break
            end

            if chunk then
                table.insert(data, chunk)
            end
        until not chunk
        resp.body = table.concat(data)
    end

    --local times, err = httpc:get_reused_times()
    --ngx.say('reused times: ', times)

    local ok, err = httpc:set_keepalive(10000, 100)
    if not ok then
        --ngx.say("failed to set keepalive: ", err)
    else
        --ngx.say('keep-alive OK');
    end

    return resp, nil
end

function request2(req)
    ngx.say('start request: ' .. req.uri)
    local rhttp = require('resty.http')
    local httpc = rhttp.new()
    local resp, err = httpc:request_uri(req.uri, req)
    ngx.say('reused times: ', httpc:get_reused_times())

    if not resp then
        local ok, err = httpc:set_keepalive()
        if not ok then
            ngx.say("<<<failed to set keepalive: ", err)
            return
        end
        return nil, err
    end

    for k, v in pairs(resp) do
        if type(v) == 'table' then
            for k2,v2 in pairs(v) do
                ngx.say('>>>> ', k2, ': ', tostring(v2))
            end
        else
            ngx.say('> ', k, ': ', tostring(v))
        end
    end

    local ok, err = httpc:set_keepalive()
    if not ok then
        ngx.say("<<<<<<<<failed to set keepalive: ", err)
        return
    end
    return resp.body, nil
    --local uri, err = httpc:parse_uri(req.url)

    --start request: http://127.0.0.1/lua/test
    --> 0: http://127.0.0.1/lua/test
    --> 1: http
    --> 2: 127.0.0.1
    --> 3: 80
    --> 4: /lua/test

    --if not uri then
    --    ngx.say('error: ', err)
    --    return nil, err
    --end

    --httpc:connect(uri[2], uri[3])
    --return 'request: ' .. req.url, nil
end


