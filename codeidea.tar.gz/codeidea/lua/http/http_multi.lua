
local http = require('lib.http')
local utils = require('utils.utils')

local tstart = utils.microtime(true)

http.multi({
    {
        id = 1,
        uri = 'http://lib.fwso.cn/test.php',
        method = 'POST',
        timeout = 2000,
        body = '{"name":"James Tang","age":28}',
        headers = {
            ['Connection'] = 'keep-alive',
        }
    },
    {
        id = 2,
        uri = 'http://lib.fwso.cn/ip.php',
        method = 'GET',
        timeout = 2000,
        --body = '{"name":"James Tang","age":28}',
        headers = {
        }
    },
})

local tc = (utils.microtime(true) - tstart) * 1000
ngx.say('Time consumed(ms): ', tc)
