

local resp = {ngx.location.capture_multi({{'/lua/test'}, {'/lua/test2'}})}

for _,r in ipairs(resp) do
    for k,v in pairs(r) do
        ngx.say(k .. ': ' .. tostring(v))
    end
end

