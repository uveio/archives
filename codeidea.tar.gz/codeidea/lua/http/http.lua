
local http = require('resty.http')

--ngx.say(package.path)
--ngx.say(package.cpath)

local httpc = http.new()
httpc:set_timeout(1000)
local c, err = httpc:connect("www.baidu.com", 80)
--local c, err = httpc:connect("127.0.0.1", 80)

if err then
    ngx.say('connect error: ', err)
    return;
end
--httpc:connect("vm1.fwso.cn", 80)
--httpc:connect("127.0.0.1", 80)

local resp, err = httpc:request({
    method = 'GET',
    --path = '/lua/test',
    path = '/',
    headers = {
        --['Host'] = 'vm1.fwso.cn',
        ['Host'] = 'www.baidu.com',
        ['Connection'] = 'keep-alive',
    },
})

if not resp then
    ngx.say('failed to request: ', err)
else
    local reader = resp.body_reader

    repeat
        local chunk, err = reader(8192)
        if err then
            ngx.log(ngx.ERR, err)
            break
        end

        if chunk then
            ngx.say(chunk)
        end
    until not chunk
end

local times, err = httpc:get_reused_times()

if not times then
    ngx.say("failed to get reused times: ", err)
else
    ngx.say("tcp reused times: ", times)
end

local ok, err = httpc:set_keepalive(10000, 100)
if not ok then
    ngx.say("failed to set keepalive: ", err)
else
    ngx.say('keep-alive OK');
end

