MAIN_VERSION = 20150114
local id = 1716016202

print('ID: ' .. _ENV.MAIN_VERSION)
print('ID: ' .. _G.MAIN_VERSION)

local utils = require('utils')

--utils.dump(package)
--print('=====')

--utils.dump(_ENV)
--print('=====')

local demo = require('demo')
o = demo:new(id)
o:hello()

demo.print_global()
demo:hello2(id)

local base = require("base")
--local obj = base.new(base, id)
local obj = base:new(id)

obj:hello()
obj.hello(obj)

base.static_hello()
obj.static_hello()
obj:static_hello()

print('======')

local sub_demo = require('sub.demo')
local obj = sub_demo:new(id)
obj:hello()
obj:sub_hello()

