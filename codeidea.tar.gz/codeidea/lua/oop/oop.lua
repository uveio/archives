
user = {
    new = function (self, name, age)
        local m = {name = name, age = age}
        return setmetatable(m, {__index = self})
    end,
    sayhello = function(self)
        print('Hello, I am ' .. self.name)
    end
}

vip_user = user:new()
function vip_user.sayhello(self)
    print('VIP: Hello, I am ' .. self.name)
end

function vip_user.info(self)
    print('VIP: Name: ' .. self.name .. ', age: ' .. self.age)
end

gvip_user = vip_user:new()
gvip_user.info = function (self)
    print('GVIP: Name: ' .. self.name .. ', age: ' .. self.age)
end

--james = user:new('James Tang', 28)
james = user.new(user, 'James Tang', 28)
james:sayhello()

peter = vip_user:new('Peter', 20)
peter:sayhello()
peter:info()

john = gvip_user:new('Join', 30)
john:info()
