local M = {}
setmetatable(M, {__index = _G})
local package_name = ...
package.loaded[package_name] = M
local _ENV = M

function new(this, id)
    return setmetatable({id = id}, {__index = this})
end

function hello(this)
    print(package_name .. ": Hello world: " .. this.id);
end

function hello2(this)
    print(package_name)
end

function print_global()
    if MAIN_VERSION then
        print(package_name .. ': main version ' .. MAIN_VERSION)
    else
        print(package_name .. ': main version does not exists')
    end

    if id then
        print(package_name .. ': id = ' .. id)
    else
        print(package_name .. ': id does not exists')
    end
end
--return M
