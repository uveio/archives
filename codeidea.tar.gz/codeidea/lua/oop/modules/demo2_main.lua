local demo2 = require('demo2')
g = 10
--hello();
demo2.hello();
