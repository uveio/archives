module(..., package.seeall)

local package_name = ...

function new(self, id)
    local base = require('base')
    setmetatable(self, {__index = base})
    return setmetatable({id=id}, {__index = self})
end

function sub_hello(self)
    print(package_name .. ": Hello: " .. self.id)
end
