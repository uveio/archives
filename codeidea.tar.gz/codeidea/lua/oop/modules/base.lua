module(..., package.seeall)
--local _G = _G
--module(...)

local package_name = ...

function new(self, id)
    local m = {id = id}
    --return _G.setmetatable(m, {__index = self})
    return setmetatable(m, {__index = self})
end

local function _hello(self)
    print(package_name .. ": Hello from base: " .. self.id)
end

function hello(self)
    _hello(self)
end

function static_hello()
    print(package_name .. ": Hello from static_hello of base")
    if MAIN_VERSION then
        print("Main version: " .. MAIN_VERSION)
    end
end

