module(..., package.seeall)

function hello(hell)
    print('Hello from demo3: ' .. hell.name)
end
