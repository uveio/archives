
class Demo:
    def hello(self):
        print 'Hello,', self.name


demo = Demo()
demo.name = "James Tang"
demo.hello()
