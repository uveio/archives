local M = {}
setmetatable(M, {__index = _G})
package.loaded[...] = M
local _ENV = M

function hello()
    print("Hello, world", g)
end

--return M
