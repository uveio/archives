local demo = require('demo3')

demo.name = "James Tang"
demo:hello()
demo.hello(demo)
