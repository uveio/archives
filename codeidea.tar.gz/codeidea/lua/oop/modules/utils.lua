module(..., package.seeall)

function dump(item, max_level, level)
    if not level then
        level = 0
    end
    if not max_level then
        max_level = 3
    end
    local pre_blank = ''
    local i = 0
    while i < level do
        pre_blank = pre_blank .. '    '
        i = i + 1
    end
    if type(item) == 'table' then
        for k,v in pairs(item) do
            print(pre_blank .. k .. ":")
            if level < max_level then
                dump(v, max_level, level + 1)
            else
                dump(tostring(v), max_level, level + 1)
            end
        end
    else
        print(pre_blank .. tostring(item))
    end
end

