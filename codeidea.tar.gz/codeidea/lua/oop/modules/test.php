<?php

class Demo {
    public function hello($this)
    {
        echo "Hello, world!" . $this->name . "\n";
    }
}


$demo = new Demo();
$demo->name = "James Tang";
$demo->hello();
