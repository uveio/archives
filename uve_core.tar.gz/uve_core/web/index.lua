--
-- UVE Unified Service(UVE v7)
--
-- @author Tang Linhua<linhua@staff.weibo.com>
-- @version 20141110
--
local core_t = require 'uve.core'
local core = core_t:new()
core:run()

