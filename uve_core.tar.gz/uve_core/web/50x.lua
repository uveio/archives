
ngx.say('{"errno":500,"error":"Internal Server Error"}')

