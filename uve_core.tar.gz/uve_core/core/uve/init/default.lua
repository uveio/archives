--
--
-- @author Li Delong(delong1@staff.weibo.com)
-- @version 20150605
--
module(..., package.seeall)

local name = ...

function run(core)
    core.debug:n('initializer');
end
