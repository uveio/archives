# UVE Core Framework

UVE Core Framework is a lightweight, ad hoc web service framework implemented with Lua/Nginx.

# Purpose 

This framework is NOT a general purpose web framework, but dedicated to coordinate backend(upstream) services. 

![Workflow overview](doc/uve-core-flow-overview.png)

# Introduction

[UVE Core Framework Introduction](http://uve.io/architecture/2016/06/19/uve-core-framework-architecture.html)
