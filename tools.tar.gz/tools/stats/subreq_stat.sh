#!/bin/bash
# 
# iostat like tool for sub request access stats
# @author Linhua Tang<linhua@staff.weibo.com>
#

if [ $# -lt 1 ]
then
    echo "Usage: $0 SUB_REQ [COUNT=10] [INTERVAL=1]"
    exit 1
fi

#date_str=`date -d "-1 minute" +"\[%d/%b/%Y:%H:%M:%S +0800\]"`
date_str=`date -d "-1 minute" +"\[%d/%b/%Y:%H:%M:"`
log_file=`ls /data0/nginx/logs/*_subreq.log 2>/dev/null`
if [ $? -ne 0 ]
then
    echo "Error: NO *_subreq.log detected"
    exit 1
fi
log_file=`echo $log_file | tail -1`
echo "Detected: $log_file"
sub_req=$1

count=10
if [ $# -ge 2 ]
then
    count=$2
fi

interval=1
if [ $# -ge 3 ]
then
    interval=$3
fi

i=0
while true
do
    i=$((i+1))
    tail -20000 $log_file | grep "$sub_req" | awk 'BEGIN{t=0;e=0}{ts[$1]+=1;t+=1;if($8 !~ /\[200\]/){e+=1}}END{max_qps=0;max_qps_k="";count=0;for(k in ts){count+=1;if (max_qps < ts[k]){max_qps=ts[k];max_qps_k=k}} printf("total: %d, error: %d, error rate: %.2f%; mean_qps: %d, max_qps: %d at %s]\n", t, e, e*100/t, t/count, max_qps, max_qps_k);}'
    if [ $i -lt $count ]
    then
        sleep $interval
    else
        break
    fi
done

