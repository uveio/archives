#!/bin/sh
# 
# iostat like tool
# @author Linhua Tang<linhua@staff.weibo.com>
#

if [ $# -gt 0 ] && [ "$1" == "-h" ]
then
    echo "Usage: $0 [FILTER|- [LIMIT [INTERVAL]]]"
    echo "Example:"
    echo "	$0 wb_feeds.php"
    echo "	$0 wb_feeds.php 1"
    echo "	$0 wb_feeds.php 1 5"
    echo "	$0 - 1 5"
    exit
fi

ACCESS="PATH_TO_ACCESS_FILE"
FILTER=`date +%Y`
if [ $# -gt 0 ] && [ "$1" != '-' ]
then
    #FILTER="grep '$1' | "
    FILTER=$1
fi

CLIMIT=10
if [ $# -gt 1 ]
then
    CLIMIT=$2
fi

INTERVAL=1
if [ $# -gt 2 ]
then
    INTERVAL=$3
fi

if [ -n "$FILTER" ]
then
    echo "Filter: $FILTER"
else
    echo "No Filter"
fi

total_pv=0
total_c=0

function finish() {
    avg=$((total_pv/total_c))
    echo "Total: $total_pv, count: $total_c, average(qps): $avg"
}

#trap finish 0

while true
do
    dt=`date -d "-2 second" +"%d/%b/%Y:%T"`;
    #echo -n "$dt - ";
    grep "$dt" $ACCESS | grep $FILTER | grep -oP '(?<=\^")[^"]+(?="\^ \^")' | awk 'BEGINE{max=0}{qps+=1;t=$1*1000;total_time+=t;if (t>max){max = t}}END{
        printf("'$dt' - qps: %4d, mean_resp_ms: %3d, max_resp_ms: %d\n", qps, total_time/qps, max);
    }';
    total_c=$((total_c+1))
    if [ $CLIMIT -gt 0 ] && [ $CLIMIT -le $total_c ]
    then
        #finish
        exit
    fi
    sleep $INTERVAL
done

