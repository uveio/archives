# Nginx Config

```
 log_format  main  '$remote_addr - $remote_user [$time_local] "$request" $request_body '
                   '^$status^ $body_bytes_sent "$http_referer" '
                   '"$http_user_agent" "$http_x_forwarded_for" ^"$request_time"^ ^"$upstream_response_time"^';
```

# Sample

```
10.77.110.50 - - [28/Jul/2016:16:16:03 +0800] "GET /uve/service/main_feed?params=349AE392993001DF HTTP/1.1" - ^200^ 871 "-" "Jakarta Commons-HttpClient/3.1" "10.77.110.50" ^"0.486"^ ^"-"^
172.16.142.204 - - [28/Jul/2016:16:17:30 +0800] "GET /interface/common_gateway.php?uve_target=3rd&posid=537f0d642866b HTTP/1.1" - ^200^ 72 "-" "-" "172.16.142.204" ^"0.011"^ ^"0.006"^
```
