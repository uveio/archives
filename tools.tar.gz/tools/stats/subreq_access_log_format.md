# Nginx Config

```
log_format sub_request '[$time_local] $uri $status $request_time [$upstream_addr] [$upstream_response_time] [$upstream_status]';
```

# Sample

```
[28/Jul/2016:16:14:35 +0800] /sm_bo_idx/boapi.php 200 0.029 [127.0.0.1:9000] [0.029] [200]
[28/Jul/2016:16:14:35 +0800] /render/v8/idx.php 200 0.003 [127.0.0.1:9000] [0.003] [200]
[28/Jul/2016:16:14:35 +0800] /hardinfo/v1/user/tags 200 0.002 [172.16.42.243:80] [0.002] [200]
[28/Jul/2016:16:14:35 +0800] /hardinfo/v1/user/tags 200 0.001 [172.16.42.243:80] [0.001] [200]
[28/Jul/2016:16:14:35 +0800] /sm_idx/idx 200 0.062 [10.13.244.200:8083] [0.062] [200]
[28/Jul/2016:16:14:35 +0800] /sm_bo_idx/boapi.php 200 0.024 [127.0.0.1:9000] [0.024] [200]
[28/Jul/2016:16:14:35 +0800] /sm_idx_group_feed/idx 200 0.042 [10.13.244.200:8083] [0.042] [200]
[28/Jul/2016:16:14:35 +0800] /sm_bo_idx/boapi.php 200 0.018 [127.0.0.1:9000] [0.018] [200]
```

