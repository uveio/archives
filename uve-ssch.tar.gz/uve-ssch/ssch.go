package main

import (
	"bufio"
	"flag"
	"log"
	"os"
	"os/exec"
	"os/signal"
	"regexp"
	"strings"
	"syscall"

	"github.com/robfig/cron"
)

const (
	ERRNO_OK = iota
	ERRNO_CONF_EMPTY
	ERRNO_CONF_OPEN_FAILED
	ERRNO_CONF_SCAN_ERROR
	ERRNO_CONF_INVALID
	ERRNO_REG_ERROR
)

var crontab = flag.String("c", "ssch.crontab", "crontab like configuration file")

func main() {
	flag.Parse()

	if *crontab == "" {
		log.Println("Error: configuration file should be specified")
		os.Exit(ERRNO_CONF_EMPTY)
	}

	log.Printf("crontab: %s\n", *crontab)
	closed := make(chan struct{})

	go func() {
		signals := make(chan os.Signal, 1)
		signal.Notify(signals, syscall.SIGINT, syscall.SIGKILL, syscall.SIGTERM)
		<-signals
		close(closed)
	}()

	fp, err := os.Open(*crontab)
	defer fp.Close()

	if err != nil {
		log.Printf("Error: failed to open file: %s, %v\n", *crontab, err)
		os.Exit(ERRNO_CONF_OPEN_FAILED)
	}

	scanner := bufio.NewScanner(fp)
	var reg *regexp.Regexp
	reg, err = regexp.Compile(`^\s*([^#\s]+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+)\s+(.+)$`)

	if err != nil {
		log.Printf("Error: failed to compile regular expression: %v\n", err)
		os.Exit(ERRNO_REG_ERROR)
	}

	cron := cron.New()
	defer cron.Stop()

	for scanner.Scan() {
		txt := scanner.Text()
		job := trimComment(txt)
		if job == "" {
			log.Printf("Ignore comment: %s\n", txt)
			continue
		}
		m := reg.FindAllStringSubmatch(job, -1)
		if m != nil {
			m0 := m[0]
			log.Printf("Added: %s | %s\n", m0[1], m0[2])
			err = cron.AddFunc(m0[1], func() { runCmd(m0[2]) })
			if err != nil {
				log.Printf("Error: failed to add job: %s\n", job)
			}
		} else {
			log.Printf("Warn: ignore line: %s\n", job)
			continue
		}
	}

	if err = scanner.Err(); err != nil {
		log.Printf("Error: sanner error: %v\n", err)
		os.Exit(ERRNO_CONF_SCAN_ERROR)
	}

	cron.Start()

	<-closed
	log.Println("exit")
}

func runCmd(cmd string) {
	reg, _ := regexp.Compile(`\s+`)
	m := reg.Split(strings.Trim(cmd, " "), -1)
	c := exec.Command(m[0])

	c.Stdout, c.Stderr = parseStdio(cmd)

	err := c.Run()
	if err != nil {
		log.Printf("Error: %v\n", err)
	}
}

func trimComment(line string) string {
	if isComment, _ := regexp.MatchString(`^\s*#`, line); isComment == true {
		return ""
	}
	reg, _ := regexp.Compile(`#.*$`)
	return reg.ReplaceAllString(line, " ")
}

func parseStdio(cmd string) (stdout *os.File, stderr *os.File) {
	if stdout != nil {
		log.Println("Not nil?")
		return
	}
	var err error
	var stdoutSameAsStderr bool
	reg, _ := regexp.Compile(`1(>+)\s*(\S+)`)
	ms := reg.FindStringSubmatch(cmd)
	if len(ms) > 2 {
		if ms[2] == "&2" {
			stdoutSameAsStderr = true
		} else {
			stdout, err = openFile(ms[2], ms[1] == ">>")
			if err != nil {
				log.Fatal(err)
			}
		}
	}

	if stdout == nil {
		reg, _ = regexp.Compile(`\s+(>+)\s*(\S+)`)
		ms = reg.FindStringSubmatch(cmd)
		if len(ms) > 2 {
			if ms[2] == "&2" {
				stdoutSameAsStderr = true
			} else {
				stdout, err = openFile(ms[2], ms[1] == ">>")
				if err != nil {
					log.Fatal(err)
				}
			}
		}
	}

	reg, _ = regexp.Compile(`\s+2(>+)\s*(\S+)`)

	ms = reg.FindStringSubmatch(cmd)
	if len(ms) > 2 {
		if ms[2] == "&1" {
			if stdoutSameAsStderr {
				stdoutSameAsStderr = false
				stdout = os.Stdout
			}
			stderr = stdout
		} else {
			stderr, err = openFile(ms[2], ms[1] == ">>")
			if err != nil {
				log.Fatal(err)
			}
		}
	}

	if stdout == nil {
		stdout = os.Stdout
	}

	if stderr == nil {
		stderr = os.Stderr
	}

	if stdoutSameAsStderr == true {
		stdout = stderr
	}

	return stdout, stderr
}

func openFile(file string, _append bool) (*os.File, error) {
	f := os.O_CREATE | os.O_WRONLY
	if _append == true {
		f |= os.O_APPEND
	}
	return os.OpenFile(file, f, 0644)
}
