#!/bin/bash

echo -n `date +"%F %T"`
echo " World"

