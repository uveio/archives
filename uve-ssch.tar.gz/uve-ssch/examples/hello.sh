#!/bin/bash

echo -n `date +"%F %T"`
echo " Hello"
sleep  3
echo -n `date +"%F %T"`
echo " Hello Again"
