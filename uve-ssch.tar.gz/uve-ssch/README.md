# uve-ssch

Cron like Shell Scheduler, based on [robfig/cron](https://github.com/robfig/cron).

## Cron Like Configuration

The configuration file looks very like the Linux/Unix crontab, but uve-ssch support 
second-level job schedule, thanks to [robfig/cron](https://github.com/robfig/cron).

Examples: 
```
*     *    *  *  *  * /path/to/scripts  # Run every second
*/10  *    *  *  *  * /path/to/scripts  # Run every 10 seconds
0     */5  *  *  *  * /path/to/scripts  # Run every 5 minutes
```

## Usage

```
uve-ssch -c /path/to/ssch.crontab
```
