//= require ./vendor/jquery
//= require ./vendor/underscore
//= require ./vendor/backbone
//= require ./vendor/bootstrap
//= require ./vendor/humanize
//= require_tree ./../templates
//= require nutcracker
//= require_tree .
//= require_self

