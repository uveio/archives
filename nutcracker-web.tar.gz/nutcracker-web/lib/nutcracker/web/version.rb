module Nutcracker
  module Web
    VERSION="0.0.11"
  end
end
