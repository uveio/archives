module Nutcracker
  VERSION = "0.4.1.20"
end
