#!/bin/bash
dest=/usr/local/sina_mobile
prefix=/usr/local/sina_mobile/luajit 
luajitv=luajit-2.1
include="$prefix/include/$luajitv"
cmodule=lualib
c="PREFIX=$prefix LUA_INCLUDE_DIR=$include DESTDIR=$dest LUA_CMODULE_DIR=$cmodule"

old=$dest/$cmodule/cjson.so

if [ -f $old ]
then
    oldbak=$old.`date +%s`
    echo "Warn: backup existing cjson.so to $oldbak"
    sudo mv $old $oldbak
fi

make clean
make $c
sudo make install $c

