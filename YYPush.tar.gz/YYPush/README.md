### collect log from directory and push to kafka   


