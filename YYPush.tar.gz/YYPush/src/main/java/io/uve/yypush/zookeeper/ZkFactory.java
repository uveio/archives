package io.uve.yypush.zookeeper;

import org.apache.log4j.Logger;

/**
 * 
 * @author yangyang21@staff.weibo.com(yangyang)
 * 
 */
public class ZkFactory {
	private static volatile ZkConfig zkConfig = null;
	private final static String connectStr;
	private static Logger log = Logger.getLogger(ZkFactory.class);

	static {
		connectStr = System.getenv("ZOOKEEPER");
		if (connectStr == null) {
            log.error("environment ZOOKEEPER does NOT exists, try `export ZOOKEEPER=zookeeper_servers`");
		}
	}

	public static ZkConfig getZkConfig() {
		if (zkConfig == null) {
			synchronized (ZkFactory.class) {
				if (zkConfig == null) {
					zkConfig = new ZkConfig(connectStr);
				}
			}
		}
		return zkConfig;
	}

	public static void resetZkConfig() {
		boolean renew = true;
		ZkConfig zk = null;
		while(renew) {
			zk = new ZkConfig(connectStr);
			boolean retry = true;
			while (retry) {
				try {
					/**
					 * if return false, I will re new Zkconfig
					 */
					renew = !zk.handleExpare();
					if(renew){
						log.info("zookeeper handle expare has catch keeper exceptin and re new zkconfig!");
						break;
					}
					retry = false;
				} catch (InterruptedException e) {
					log.info("zookeeper handle expare has been inter and retry!");
				}
			}
		}

		log.info("zookeeper handle expare success!");
		zkConfig = zk;
	}
}
