#!/bin/bash

mvn clean package
