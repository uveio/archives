#!/bin/bash
#@author

WORK_DIR=/data0/logpush
JAR=$WORK_DIR/yypush-0.0.3-jar-with-dependencies.jar
LOGFILE=$WORK_DIR/logpush.log
#PIDFILE=$WORK_DIR/logpush.pid

usage()
{
  echo "Usage: ${0##*/} [-d] {start|stop} "
  exit 1
}

# export zookeeper="ZKHOST:ZKPORT,ZKHOST:ZKPORT"

if [ ! -f "$JAR" ]
then
   echo -e "\e[31mError: $JAR does not exists\e[0m"
   exit 1
fi

if [ "$ZOOKEEPER" == "" ]
then
    echo -e "\e[31mZOOKEEPER is NOT defined, try: export ZOOKEEPER=ZKHOST:ZKPORT,ZKHOST:ZKPORT\e[0m"
    exit 1
fi

javabin=`which java`

if [ "$javabin" == "" ]
then
    echo -e "\e[31mjava NOT installed, try: sudo yum install -y java-1.7.0-openjdk\e[0m"
    exit 1
fi

javav=`java -version 2>&1 | awk '/version/{print substr($3, 2, 3)}'`

if [[ "$javav" < "1.7" ]]
then
    echo -e "\e[31mError: required java version 1.7+, your java version: $javav\e[0m"
    exit 1
fi

[ $# -gt 0 ] || usage

DEBUG=0
while [[ $1 = -* ]]; do
  case $1 in
     -d) DEBUG=1 ;;
  esac
  shift
done
ACTION=$1
shift

cd $WORK_DIR

case "$ACTION" in
  start)
    echo "Starting logpush ... "
    pid=`ps -o pid,cmd -C java | grep yypush | awk '{print $1}'`
    if [ "$pid" == "" ]
    then
        java -server -XX:MaxDirectMemorySize=2g -Xmx2g -XX:+UseConcMarkSweepGC -cp $JAR io.uve.yypush.Sailing > $LOGFILE 2>&1 &
	sleep 5
        pid=`ps -o pid,cmd -C java | grep yypush | awk '{print $1}'`
        if [ "$pid" == "" ]
        then
            echo -e "\e[31mError: failed to start\e[0m"
            cat $LOGFILE
        else
            echo "Started, running with PID:$pid "
        fi
    else
        echo -e "\e[33mWarning: already running with PID: $pid\e[0m"
    fi
  ;;

  stop)
    echo "Stoping logpush ... "
    pid=`ps -o pid,cmd -C java | grep yypush | awk '{print $1}'`
    if [ "$pid" == "" ]
    then
        echo -e "\e[33mWarning: YYPush not running\e[0m"
    else
        kill $pid
        echo "Stop pid: $pid "
    fi
  ;;
esac

exit 0
