#!/bin/bash

export GOPATH=`pwd`
export PATH=$GOROOT/bin:$PATH
