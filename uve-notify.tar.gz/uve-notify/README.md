# UVE Notity

[![Build Status](https://travis-ci.org/uveio/uve-notify.svg?branch=master)](https://travis-ci.org/uveio/uve-notify)

## Features

- 对不同graphite_beacon的alert支持不同的报警分组
- 相同前缀的alert使用同一组报警
- 自定义报警方式(目前支持mail & slack)
- 不仅针对graphite-beacon报警，还可以直接使用http请求调用

## Service Config Example

[conf.json](./conf.json)

## Graphite-Beacon Integration

```
{
  "http": {
      "url": "http://UVE_NOTIFY_HOST:8080/",
      "method": "POST"
  }
}
```

## Http Request

- curl -X POST http://UVE\_NOTIFY\_HOST:8080 -d "level=warning&desc=describe&alert=TestAlert1:XXXX&noemail=1"
- level: 报警级别
- desc: 报警内容
- alert: 报警分组
- noemail: 可选参数,noemail=1不启用邮件通知,优先级大于配置文件

## reference

- [graphte](https://github.com/klen/graphite-beacon)
- [graphite-beacon](https://github.com/graphite-project/graphite-web)
