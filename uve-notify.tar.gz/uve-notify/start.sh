#!/bin/bash
./bin/gbhserver -conf conf.json
